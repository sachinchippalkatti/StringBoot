package com.sachin.mongotempleate.mongotemplateexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongotemplateexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongotemplateexampleApplication.class, args);
	}

}
