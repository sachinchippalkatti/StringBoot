package com.mysql.connection.serviceMysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceMysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceMysqlApplication.class, args);
	}

}
