package com.att.cti.LTEmon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LtEmonApplication {

	public static void main(String[] args) {
		SpringApplication.run(LtEmonApplication.class, args);
	}

}
