package com.example.lifeSight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LifeSightApplication {

	public static void main(String[] args) {
		SpringApplication.run(LifeSightApplication.class, args);
	}

}
