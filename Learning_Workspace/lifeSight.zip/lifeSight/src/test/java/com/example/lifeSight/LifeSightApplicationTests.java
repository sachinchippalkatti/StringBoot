package com.example.lifeSight;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LifeSightApplicationTests {

	@Test
	void contextLoads() {
	}

}
