package com.example.sachin.RestServiceDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestServiceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestServiceDemoApplication.class, args);
	}

}
