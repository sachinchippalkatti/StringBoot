package com.sachin.mockito.demoMockito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMockitoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMockitoApplication.class, args);
	}

}
